import { useRef, useEffect, useState } from "react";
import { FaTimes, FaFileInvoice, FaBuilding, FaBoxOpen, FaCheckCircle, FaFileAlt, FaPrint } from "react-icons/fa";
import { pdf } from "@react-pdf/renderer";
import PurchaseOrderPDF from "./PurchaseOrderPDF";
import { markItemPurchased, getPurchaseOrder } from "../../services/purchaseOrderService";
import AlertToast from "../ui/AlertToast";
import ConfirmDialog from "../ui/ConfirmDialog";

const PurchaseOrderModal = ({ open, onClose, data, onShowAlert, onUpdate }) => {
    const modalRef = useRef(null);

    // Close on escape key
    useEffect(() => {
        const handleKeyDown = (e) => {
            if (e.key === "Escape") onClose();
        };

        if (open) {
            document.addEventListener("keydown", handleKeyDown);
        }
        return () => document.removeEventListener("keydown", handleKeyDown);
    }, [open, onClose]);

    const [items, setItems] = useState([]);
    const [selectedIds, setSelectedIds] = useState(new Set());
    const [processing, setProcessing] = useState(false);
    const [generatingPdf, setGeneratingPdf] = useState(false);

    // UI State
    const [showConfirm, setShowConfirm] = useState(false);

    // ... imports

    const [poData, setPoData] = useState(null);

    useEffect(() => {
        const fetchData = async () => {
            if (data && data.id) {
                try {
                    const fullData = await getPurchaseOrder(data.id);
                    setPoData(fullData);
                    setItems(fullData.items || []);
                } catch (error) {
                    console.error("Failed to fetch PO details", error);
                    // Fallback
                    setPoData(data);
                    setItems(data.items || []);
                }
            } else if (data) {
                setPoData(data);
                setItems(data.items || []);
            }
        };

        if (open) {
            fetchData();
        }
    }, [data, open]);

    // Close on click outside
    const handleBackdropClick = (e) => {
        if (modalRef.current && !modalRef.current.contains(e.target)) {
            onClose();
        }
    };

    const handleCheckboxChange = (itemId) => {
        const newSelected = new Set(selectedIds);
        if (newSelected.has(itemId)) {
            newSelected.delete(itemId);
        } else {
            newSelected.add(itemId);
        }
        setSelectedIds(newSelected);
    };

    const handleProceed = () => {
        if (selectedIds.size === 0) {
            onShowAlert("error", "Select items to mark as received");
            return;
        }
        setShowConfirm(true);
    };

    const processBatchPurchase = async () => {
        setProcessing(true);
        let successCount = 0;
        let errors = 0;

        // Clone items to update locally
        const newItems = [...items];

        for (const itemId of selectedIds) {
            try {
                // Call API for each selected item as per previous instruction context
                await markItemPurchased(data.id, itemId);

                // Update local status
                const idx = newItems.findIndex(i => i.id === itemId);
                if (idx !== -1) {
                    newItems[idx] = { ...newItems[idx], is_received: true };
                }
                successCount++;
            } catch (err) {
                console.error(err);
                errors++;
            }
        }

        setItems(newItems);
        setSelectedIds(new Set()); // Clear selections
        setProcessing(false);
        setShowConfirm(false);

        if (errors === 0) {
            onShowAlert("success", `${successCount} items marked as purchased successfully.`);
            if (onUpdate) onUpdate();
        } else {
            onShowAlert("warning", `Marked ${successCount} items. Failed: ${errors}`);
            if (successCount > 0 && onUpdate) onUpdate();
        }
    };

    const handlePrint = async () => {
        if (!poData) return;
        setGeneratingPdf(true);
        try {
            const blob = await pdf(<PurchaseOrderPDF details={poData} />).toBlob();
            const url = URL.createObjectURL(blob);
            window.open(url, '_blank');
        } catch (error) {
            console.error("Error generating PDF:", error);
            if (onShowAlert) onShowAlert("error", "Failed to generate PDF");
        } finally {
            setGeneratingPdf(false);
        }
    };

    if (!open || !data) return null;

    return (
        <div
            className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-sm transition-opacity"
            onClick={handleBackdropClick}
        >
            <div
                ref={modalRef}
                className="bg-white w-full max-w-4xl max-h-[90vh] rounded-2xl shadow-2xl flex flex-col overflow-hidden animate-in fade-in zoom-in-95 duration-200"
            >
                {/* HEADER */}
                <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 bg-slate-50/50">
                    <div className="flex items-center gap-3">
                        <div className="bg-blue-100 text-blue-600 p-2 rounded-lg">
                            <FaFileInvoice className="text-xl" />
                        </div>
                        <div>
                            <h3 className="text-lg font-bold text-slate-800">Purchase Order Details</h3>
                            <p className="text-sm text-slate-500 font-mono">{poData?.po_number || data?.po_number}</p>
                        </div>
                    </div>
                    <div className="flex items-center gap-3">
                        <button
                            onClick={handlePrint}
                            disabled={generatingPdf}
                            className="flex items-center gap-2 px-3 py-1.5 text-slate-700 hover:text-blue-500 text-sm font-semibold rounded-lg hover:bg-blue-50 transition-colors disabled:opacity-50"
                            title="Print / Preview PDF"
                        >
                            {generatingPdf ? <div className="animate-spin h-4 w-4 border-2 border-blue-600 rounded-full border-t-transparent"></div> : <FaPrint size={20} />}

                        </button>
                        <button
                            onClick={onClose}
                            className="p-2 text-slate-500 hover:text-red-600 hover:bg-red-50 rounded-full transition-colors"
                        >
                            <FaTimes />
                        </button>
                    </div>
                </div>

                {/* SCROLLABLE CONTENT */}
                <div className="flex-1 overflow-y-auto p-6 space-y-6">

                    {(!poData) ? (
                        <div className="text-center py-12 text-slate-500 animate-pulse">Loading details...</div>
                    ) : (
                        <>
                            {/* INFO GRID */}
                            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                                <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
                                    <div className="flex items-center gap-2 mb-2">
                                        <FaBuilding className="text-slate-400" />
                                        <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Vendor</span>
                                    </div>
                                    <div className="font-semibold text-slate-800">{poData.vendor_name}</div>
                                
                                </div>

                                <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
                                    <div className="flex items-center gap-2 mb-2">
                                        <FaBoxOpen className="text-slate-400" />
                                        <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Requisition</span>
                                    </div>
                                    <div className="font-semibold text-slate-800">{poData.requisition_number}</div>
                                </div>

                                <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
                                    <div className="flex items-center gap-2 mb-2">
                                        <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Status</span>
                                    </div>
                                    {(() => {
                                        const allReceived = items && items.length > 0 && items.every(i => i.is_received);
                                        const someReceived = items && items.length > 0 && items.some(i => i.is_received);

                                        let displayStatus = poData.status;
                                        if (allReceived) {
                                            displayStatus = 'COMPLETED';
                                        } else if (someReceived) {
                                            displayStatus = 'PARTIALLY_RECEIVED';
                                        }

                                        let statusText = displayStatus;
                                        if (displayStatus === 'PENDING') statusText = 'Pending';
                                        else if (displayStatus === 'PARTIALLY_RECEIVED') statusText = 'Partially Received';
                                        else if (displayStatus === 'COMPLETED') statusText = 'Completed';
                                        else if (displayStatus === 'CANCELLED') statusText = 'Cancelled';

                                        return (
                                            <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium 
                                                ${displayStatus === 'PENDING' ? 'bg-yellow-100 text-yellow-800' :
                                                    displayStatus === 'PARTIALLY_RECEIVED' ? 'bg-blue-100 text-blue-800' :
                                                        displayStatus === 'COMPLETED' ? 'bg-emerald-100 text-emerald-800' :
                                                            displayStatus === 'CANCELLED' ? 'bg-red-100 text-red-800' :
                                                                'bg-slate-100 text-slate-800'}`}>
                                                {statusText}
                                            </span>
                                        );
                                    })()}
                                    <div className="text-sm text-slate-500 mt-2">
                                        Created: {new Date(poData.created_at).toLocaleDateString()}
                                    </div>
                                </div>
                            </div>

                            {/* ITEMS TABLE */}
                            <div>
                                <h4 className="text-sm font-bold text-slate-700 uppercase tracking-wider mb-3">Order Items ({poData.items?.length || 0})</h4>
                                <div className="border border-slate-200 rounded-lg overflow-hidden">
                                    <table className="w-full text-left text-sm">
                                        <thead className="bg-slate-50 text-slate-600 font-semibold border-b border-slate-200">
                                            <tr>
                                                <th className="px-4 py-3">Product</th>
                                                <th className="px-4 py-3 text-right">HSN</th>
                                                <th className="px-4 py-3 text-right">Quantity</th>
                                                <th className="px-4 py-3 text-right">Rate</th>
                                                <th className="px-4 py-3 text-right">Amount</th>
                                                <th className="px-4 py-3 text-right">Purchase</th>
                                            </tr>
                                        </thead>
                                        <tbody className="divide-y divide-slate-100">
                                            {items.map((item) => (
                                                <tr key={item.id} className="odd:bg-slate-100 even:bg-white hover:bg-slate-200   ">
                                                    <td className="px-4 py-3">
                                                        <div className="font-medium text-slate-800">{item.product_name}</div>
                                                        <div className="text-xs text-slate-500 font-mono">{item.product_code}</div>
                                                    </td>
                                                    <td className="px-4 py-3 text-right">
                                                        {item.hsn_code}
                                                    </td>
                                                    <td className="px-4 py-3 text-right">
                                                        {item.quantity} <span className="text-xs text-slate-400">{item.unit}</span>
                                                    </td>
                                                    <td className="px-4 py-3 text-right font-mono">
                                                        ₹ {parseFloat(item.rate).toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                                                    </td>
                                                    <td className="px-4 py-3 text-right font-bold text-slate-800 font-mono">
                                                        ₹ {parseFloat(item.amount).toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                                                    </td>
                                                    <td className="px-4 py-3 text-right">
                                                        <input
                                                            type="checkbox"
                                                            disabled={item.is_received || processing}
                                                            checked={item.is_received || selectedIds.has(item.id)}
                                                            onChange={() => !item.is_received && handleCheckboxChange(item.id)}
                                                            className={`w-4 h-4 rounded focus:ring-blue-500 cursor-pointer 
                                                        ${item.is_received
                                                                    ? "text-green-600 bg-green-100 border-green-300 cursor-not-allowed"
                                                                    : "text-blue-600 bg-gray-100 border-gray-300"}`}
                                                        />
                                                    </td>
                                                </tr>
                                            ))}
                                            {(!poData.items || poData.items.length === 0) && (
                                                <tr>
                                                    <td colSpan="6" className="px-4 py-8 text-center text-slate-400">
                                                        No items in this order.
                                                    </td>
                                                </tr>
                                            )}
                                        </tbody>
                                        <tfoot className="bg-slate-50 border-t border-slate-200 font-bold text-slate-800">
                                            {poData.freight_cost > 0 && (
                                                <>
                                                    <tr>
                                                        <td colSpan="4" className="px-4 py-2 text-right text-slate-500 font-medium">Sub Total:</td>
                                                        <td className="px-4 py-2 text-right font-mono">
                                                            ₹ {(parseFloat(poData.total_amount) - parseFloat(poData.freight_cost)).toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                                                        </td>
                                                        <td></td>
                                                    </tr>
                                                    <tr>
                                                        <td colSpan="4" className="px-4 py-2 text-right text-slate-500 font-medium">Freight Cost:</td>
                                                        <td className="px-4 py-2 text-right font-mono">
                                                            ₹ {parseFloat(poData.freight_cost).toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                                                        </td>
                                                        <td></td>
                                                    </tr>
                                                </>
                                            )}
                                            <tr>
                                                <td colSpan="4" className="px-4 py-3 text-right text-base">Total Amount:</td>
                                                <td className="px-4 py-3 text-right text-lg text-blue-600 font-mono">
                                                    {parseFloat(poData.total_amount).toLocaleString('en-IN', { style: 'currency', currency: 'INR' })}
                                                </td>
                                                <td></td>
                                            </tr>
                                        </tfoot>
                                    </table>
                                </div>
                            </div>
                        </>
                    )}
                </div>

                {/* FOOTER */}
                <div className="px-6 py-4 border-t border-slate-100 bg-slate-50 justify-end flex gap-3">
                    <button
                        onClick={onClose}
                        disabled={processing}
                        className="px-4 py-2 bg-white border border-slate-300 text-slate-700 font-semibold rounded-lg hover:bg-slate-50 transition-colors"
                    >
                        Close
                    </button>
                    <button
                        onClick={handleProceed}
                        disabled={processing || selectedIds.size === 0}
                        className="px-4 py-2 bg-blue-600 text-white font-semibold rounded-lg hover:bg-blue-700 disabled:opacity-50 transition-colors shadow-sm"
                    >
                        {processing ? "Processing..." : "Proceed"}
                    </button>
                </div>
            </div>

            <ConfirmDialog
                open={showConfirm}
                title="Mark Items as Purchased"
                message={`Are you sure you want to mark ${selectedIds.size} selected items as purchased/received?`}
                confirmText="Confirm Purchase"
                loading={processing}
                onCancel={() => setShowConfirm(false)}
                onConfirm={processBatchPurchase}
                icon={FaCheckCircle}
                confirmButtonClass="bg-blue-600 hover:bg-blue-700"
                iconBgClass="bg-blue-100 text-blue-600"
            />


        </div>
    );
};

export default PurchaseOrderModal;
